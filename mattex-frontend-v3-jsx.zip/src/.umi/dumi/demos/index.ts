// @ts-nocheck
import React from 'react';
import { dynamic } from 'dumi';

export default {
  'components-demo': {
    component: dynamic({
  loader: async function () {
    var _interopRequireDefault = require("D:/work project/mattex/mattex-frontend-v3-jsx/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/interopRequireDefault.js").default;

    var _react = _interopRequireDefault(await import("react"));

    var _Footer = _interopRequireDefault(await import("@/components/Footer"));

    var _default = function _default() {
      return /*#__PURE__*/_react.default.createElement(_Footer.default, null);
    };

    return _default;
  },
  loading: () => null
}),
    previewerProps: {"sources":{"_":{"tsx":"import React from 'react';\nimport Footer from '@/components/Footer';\n\nexport default () => <Footer />;"}},"dependencies":{"react":{"version":"17.0.2"}},"background":"#f0f2f5","identifier":"components-demo"},
  },
  'components-demo-1': {
    component: dynamic({
  loader: async function () {
    var _interopRequireDefault = require("D:/work project/mattex/mattex-frontend-v3-jsx/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/interopRequireDefault.js").default;

    var _antd = await import("antd");

    var _react = _interopRequireDefault(await import("react"));

    var _HeaderDropdown = _interopRequireDefault(await import("@/components/HeaderDropdown"));

    var _default = function _default() {
      var menuHeaderDropdown = /*#__PURE__*/_react.default.createElement(_antd.Menu, {
        selectedKeys: []
      }, /*#__PURE__*/_react.default.createElement(_antd.Menu.Item, {
        key: "center"
      }, "profile"), /*#__PURE__*/_react.default.createElement(_antd.Menu.Item, {
        key: "settings"
      }, "setting"), /*#__PURE__*/_react.default.createElement(_antd.Menu.Divider, null), /*#__PURE__*/_react.default.createElement(_antd.Menu.Item, {
        key: "logout"
      }, "logout"));

      return /*#__PURE__*/_react.default.createElement(_HeaderDropdown.default, {
        overlay: menuHeaderDropdown
      }, /*#__PURE__*/_react.default.createElement(_antd.Button, null, "hover to show menu"));
    };

    return _default;
  },
  loading: () => null
}),
    previewerProps: {"sources":{"_":{"tsx":"import { Button, Menu } from 'antd';\nimport React from 'react';\nimport HeaderDropdown from '@/components/HeaderDropdown';\n\nexport default () => {\n  const menuHeaderDropdown = (\n    <Menu selectedKeys={[]}>\n      <Menu.Item key=\"center\">profile</Menu.Item>\n      <Menu.Item key=\"settings\">setting</Menu.Item>\n      <Menu.Divider />\n      <Menu.Item key=\"logout\">logout</Menu.Item>\n    </Menu>\n  );\n  return (\n    <HeaderDropdown overlay={menuHeaderDropdown}>\n      <Button>hover to show menu</Button>\n    </HeaderDropdown>\n  );\n};"}},"dependencies":{"antd":{"version":"4.22.5","css":"antd/dist/antd.css"},"react":{"version":">=16.9.0"},"react-dom":{"version":">=16.9.0"}},"background":"#f0f2f5","identifier":"components-demo-1"},
  },
  'components-demo-2': {
    component: dynamic({
  loader: async function () {
    var _interopRequireDefault = require("D:/work project/mattex/mattex-frontend-v3-jsx/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/interopRequireDefault.js").default;

    var _react = _interopRequireDefault(await import("react"));

    var _HeaderSearch = _interopRequireDefault(await import("@/components/HeaderSearch"));

    var _default = function _default() {
      return /*#__PURE__*/_react.default.createElement(_HeaderSearch.default, {
        placeholder: "in-site searching",
        defaultValue: "umi ui",
        options: [{
          label: 'Ant Design Pro',
          value: 'Ant Design Pro'
        }, {
          label: 'Ant Design',
          value: 'Ant Design'
        }, {
          label: 'Pro Table',
          value: 'Pro Table'
        }, {
          label: 'Pro Layout',
          value: 'Pro Layout'
        }],
        onSearch: function onSearch(value) {
          console.log('input', value);
        }
      });
    };

    return _default;
  },
  loading: () => null
}),
    previewerProps: {"sources":{"_":{"tsx":"import { Button, Menu } from 'antd';\nimport React from 'react';\nimport HeaderSearch from '@/components/HeaderSearch';\n\nexport default () => {\n  return (\n    <HeaderSearch\n      placeholder=\"in-site searching\"\n      defaultValue=\"umi ui\"\n      options={[\n        { label: 'Ant Design Pro', value: 'Ant Design Pro' },\n        {\n          label: 'Ant Design',\n          value: 'Ant Design',\n        },\n        {\n          label: 'Pro Table',\n          value: 'Pro Table',\n        },\n        {\n          label: 'Pro Layout',\n          value: 'Pro Layout',\n        },\n      ]}\n      onSearch={(value) => {\n        console.log('input', value);\n      }}\n    />\n  );\n};"}},"dependencies":{"react":{"version":"17.0.2"}},"background":"#f0f2f5","identifier":"components-demo-2"},
  },
  'components-demo-3': {
    component: dynamic({
  loader: async function () {
    var _interopRequireDefault = require("D:/work project/mattex/mattex-frontend-v3-jsx/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/interopRequireDefault.js").default;

    var _antd = await import("antd");

    var _react = _interopRequireDefault(await import("react"));

    var _NoticeIcon = _interopRequireDefault(await import("@/components/NoticeIcon/NoticeIcon"));

    var _default = function _default() {
      var list = [{
        id: '000000001',
        avatar: 'https://gw.alipayobjects.com/zos/rmsportal/ThXAXghbEsBCCSDihZxY.png',
        title: '你收到了 14 份新周报',
        datetime: '2017-08-09',
        type: 'notification'
      }, {
        id: '000000002',
        avatar: 'https://gw.alipayobjects.com/zos/rmsportal/OKJXDXrmkNshAMvwtvhu.png',
        title: '你推荐的 曲妮妮 已通过第三轮面试',
        datetime: '2017-08-08',
        type: 'notification'
      }];
      return /*#__PURE__*/_react.default.createElement(_NoticeIcon.default, {
        count: 10,
        onItemClick: function onItemClick(item) {
          _antd.message.info("".concat(item.title, " is clicked"));
        },
        onClear: function onClear(title, key) {
          return _antd.message.info('clear more is clicked');
        },
        loading: false,
        clearText: "clear",
        viewMoreText: "view more",
        onViewMore: function onViewMore() {
          return _antd.message.info('view more is clicked');
        },
        clearClose: true
      }, /*#__PURE__*/_react.default.createElement(_NoticeIcon.default.Tab, {
        tabKey: "notification",
        count: 2,
        list: list,
        title: "notification",
        emptyText: "no new notification",
        showViewMore: true
      }), /*#__PURE__*/_react.default.createElement(_NoticeIcon.default.Tab, {
        tabKey: "message",
        count: 2,
        list: list,
        title: "message",
        emptyText: "no new message",
        showViewMore: true
      }), /*#__PURE__*/_react.default.createElement(_NoticeIcon.default.Tab, {
        tabKey: "event",
        title: "event",
        emptyText: "no coming up event",
        count: 2,
        list: list,
        showViewMore: true
      }));
    };

    return _default;
  },
  loading: () => null
}),
    previewerProps: {"sources":{"_":{"tsx":"import { message } from 'antd';\nimport React from 'react';\nimport NoticeIcon from '@/components/NoticeIcon/NoticeIcon';\n\nexport default () => {\n  const list = [\n    {\n      id: '000000001',\n      avatar: 'https://gw.alipayobjects.com/zos/rmsportal/ThXAXghbEsBCCSDihZxY.png',\n      title: '你收到了 14 份新周报',\n      datetime: '2017-08-09',\n      type: 'notification',\n    },\n    {\n      id: '000000002',\n      avatar: 'https://gw.alipayobjects.com/zos/rmsportal/OKJXDXrmkNshAMvwtvhu.png',\n      title: '你推荐的 曲妮妮 已通过第三轮面试',\n      datetime: '2017-08-08',\n      type: 'notification',\n    },\n  ];\n  return (\n    <NoticeIcon\n      count={10}\n      onItemClick={(item) => {\n        message.info(`${item.title} is clicked`);\n      }}\n      onClear={(title: string, key: string) => message.info('clear more is clicked')}\n      loading={false}\n      clearText=\"clear\"\n      viewMoreText=\"view more\"\n      onViewMore={() => message.info('view more is clicked')}\n      clearClose\n    >\n      <NoticeIcon.Tab\n        tabKey=\"notification\"\n        count={2}\n        list={list}\n        title=\"notification\"\n        emptyText=\"no new notification\"\n        showViewMore\n      />\n      <NoticeIcon.Tab\n        tabKey=\"message\"\n        count={2}\n        list={list}\n        title=\"message\"\n        emptyText=\"no new message\"\n        showViewMore\n      />\n      <NoticeIcon.Tab\n        tabKey=\"event\"\n        title=\"event\"\n        emptyText=\"no coming up event\"\n        count={2}\n        list={list}\n        showViewMore\n      />\n    </NoticeIcon>\n  );\n};"}},"dependencies":{"antd":{"version":"4.22.5","css":"antd/dist/antd.css"},"react":{"version":">=16.9.0"},"react-dom":{"version":">=16.9.0"}},"background":"#f0f2f5","identifier":"components-demo-3"},
  },
};
