// @ts-nocheck
const noop = () => {};

export const message = {
  warn: noop,
  error: noop,
};

export const notification = {
  open: noop,
};
