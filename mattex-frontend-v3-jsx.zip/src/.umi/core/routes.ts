// @ts-nocheck
import React from 'react';
import { ApplyPluginsType, dynamic } from 'D:/work project/mattex/mattex-frontend-v3-jsx/node_modules/umi/node_modules/@umijs/runtime';
import * as umiExports from './umiExports';
import { plugin } from './plugin';
import LoadingComponent from '@ant-design/pro-layout/es/PageLoading';

export function getRoutes() {
  const routes = [
  {
    "path": "/umi/plugin/openapi",
    "component": dynamic({ loader: () => import(/* webpackChunkName: '.umi__plugin-openapi__openapi' */'D:/work project/mattex/mattex-frontend-v3-jsx/src/.umi/plugin-openapi/openapi.tsx'), loading: LoadingComponent})
  },
  {
    "path": "/",
    "component": dynamic({ loader: () => import(/* webpackChunkName: '.umi__plugin-layout__Layout' */'D:/work project/mattex/mattex-frontend-v3-jsx/src/.umi/plugin-layout/Layout.tsx'), loading: LoadingComponent}),
    "routes": [
      {
        "path": "/~demos/:uuid",
        "layout": false,
        "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'../dumi/layout'), loading: LoadingComponent})],
        "component": ((props) => dynamic({
          loader: async () => {
            const React = await import('react');
            const { default: getDemoRenderArgs } = await import(/* webpackChunkName: 'dumi_demos' */ 'D:/work project/mattex/mattex-frontend-v3-jsx/node_modules/@umijs/preset-dumi/lib/plugins/features/demo/getDemoRenderArgs');
            const { default: Previewer } = await import(/* webpackChunkName: 'dumi_demos' */ 'dumi-theme-default/es/builtins/Previewer.js');
            const { usePrefersColor, context } = await import(/* webpackChunkName: 'dumi_demos' */ 'dumi/theme');

            return props => {
              
      const { demos } = React.useContext(context);
      const [renderArgs, setRenderArgs] = React.useState([]);

      // update render args when props changed
      React.useLayoutEffect(() => {
        setRenderArgs(getDemoRenderArgs(props, demos));
      }, [props.match.params.uuid, props.location.query.wrapper, props.location.query.capture]);

      // for listen prefers-color-schema media change in demo single route
      usePrefersColor();

      switch (renderArgs.length) {
        case 1:
          // render demo directly
          return renderArgs[0];

        case 2:
          // render demo with previewer
          return React.createElement(
            Previewer,
            renderArgs[0],
            renderArgs[1],
          );

        default:
          return `Demo ${props.match.params.uuid} not found :(`;
      }
    
            }
          },
          loading: () => null,
        }))()
      },
      {
        "path": "/_demos/:uuid",
        "redirect": "/~demos/:uuid"
      },
      {
        "__dumiRoot": true,
        "layout": false,
        "path": "/~docs",
        "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'../dumi/layout'), loading: LoadingComponent}), dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'D:/work project/mattex/mattex-frontend-v3-jsx/node_modules/dumi-theme-default/es/layout.js'), loading: LoadingComponent})],
        "routes": [
          {
            "path": "/~docs",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'README.md' */'D:/work project/mattex/mattex-frontend-v3-jsx/README.md'), loading: LoadingComponent}),
            "exact": true,
            "meta": {
              "locale": "en-US",
              "order": null,
              "filePath": "README.md",
              "updatedTime": 1660555776905,
              "slugs": [
                {
                  "depth": 1,
                  "value": "Mattex-frontend-v3-jsx",
                  "heading": "mattex-frontend-v3-jsx"
                },
                {
                  "depth": 2,
                  "value": "Getting started",
                  "heading": "getting-started"
                },
                {
                  "depth": 2,
                  "value": "Add your files",
                  "heading": "add-your-files"
                },
                {
                  "depth": 2,
                  "value": "Integrate with your tools",
                  "heading": "integrate-with-your-tools"
                },
                {
                  "depth": 2,
                  "value": "Collaborate with your team",
                  "heading": "collaborate-with-your-team"
                },
                {
                  "depth": 2,
                  "value": "Test and Deploy",
                  "heading": "test-and-deploy"
                },
                {
                  "depth": 1,
                  "value": "Editing this README",
                  "heading": "editing-this-readme"
                },
                {
                  "depth": 2,
                  "value": "Suggestions for a good README",
                  "heading": "suggestions-for-a-good-readme"
                },
                {
                  "depth": 2,
                  "value": "Name",
                  "heading": "name"
                },
                {
                  "depth": 2,
                  "value": "Description",
                  "heading": "description"
                },
                {
                  "depth": 2,
                  "value": "Badges",
                  "heading": "badges"
                },
                {
                  "depth": 2,
                  "value": "Visuals",
                  "heading": "visuals"
                },
                {
                  "depth": 2,
                  "value": "Installation",
                  "heading": "installation"
                },
                {
                  "depth": 2,
                  "value": "Usage",
                  "heading": "usage"
                },
                {
                  "depth": 2,
                  "value": "Support",
                  "heading": "support"
                },
                {
                  "depth": 2,
                  "value": "Roadmap",
                  "heading": "roadmap"
                },
                {
                  "depth": 2,
                  "value": "Contributing",
                  "heading": "contributing"
                },
                {
                  "depth": 2,
                  "value": "Authors and acknowledgment",
                  "heading": "authors-and-acknowledgment"
                },
                {
                  "depth": 2,
                  "value": "License",
                  "heading": "license"
                },
                {
                  "depth": 2,
                  "value": "Project status",
                  "heading": "project-status"
                },
                {
                  "depth": 1,
                  "value": "If you have run out of energy or time for your project, put a note at the top of the README saying that development has slowed down or stopped completely. Someone may choose to fork your project or volunteer to step in as a maintainer or owner, allowing your project to keep going. You can also make an explicit request for maintainers.",
                  "heading": "if-you-have-run-out-of-energy-or-time-for-your-project-put-a-note-at-the-top-of-the-readme-saying-that-development-has-slowed-down-or-stopped-completely-someone-may-choose-to-fork-your-project-or-volunteer-to-step-in-as-a-maintainer-or-owner-allowing-your-project-to-keep-going-you-can-also-make-an-explicit-request-for-maintainers"
                },
                {
                  "depth": 1,
                  "value": "Ant Design Pro",
                  "heading": "ant-design-pro"
                },
                {
                  "depth": 2,
                  "value": "Environment Prepare",
                  "heading": "environment-prepare"
                },
                {
                  "depth": 2,
                  "value": "Provided Scripts",
                  "heading": "provided-scripts"
                },
                {
                  "depth": 3,
                  "value": "Start project",
                  "heading": "start-project"
                },
                {
                  "depth": 3,
                  "value": "Build project",
                  "heading": "build-project"
                },
                {
                  "depth": 3,
                  "value": "Check code style",
                  "heading": "check-code-style"
                },
                {
                  "depth": 3,
                  "value": "Test code",
                  "heading": "test-code"
                },
                {
                  "depth": 2,
                  "value": "More",
                  "heading": "more"
                }
              ],
              "title": "Mattex-frontend-v3-jsx"
            },
            "title": "Mattex-frontend-v3-jsx"
          },
          {
            "path": "/~docs/components",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'components__index.md' */'D:/work project/mattex/mattex-frontend-v3-jsx/src/components/index.md'), loading: LoadingComponent}),
            "exact": true,
            "meta": {
              "filePath": "src/components/index.md",
              "updatedTime": 1660555776915,
              "title": "业务组件",
              "sidemenu": false,
              "slugs": [
                {
                  "depth": 1,
                  "value": "业务组件",
                  "heading": "业务组件"
                },
                {
                  "depth": 2,
                  "value": "Footer 页脚组件",
                  "heading": "footer-页脚组件"
                },
                {
                  "depth": 2,
                  "value": "HeaderDropdown 头部下拉列表",
                  "heading": "headerdropdown-头部下拉列表"
                },
                {
                  "depth": 2,
                  "value": "HeaderSearch 头部搜索框",
                  "heading": "headersearch-头部搜索框"
                },
                {
                  "depth": 3,
                  "value": "API",
                  "heading": "api"
                },
                {
                  "depth": 2,
                  "value": "NoticeIcon 通知工具",
                  "heading": "noticeicon-通知工具"
                },
                {
                  "depth": 3,
                  "value": "NoticeIcon API",
                  "heading": "noticeicon-api"
                },
                {
                  "depth": 3,
                  "value": "NoticeIcon.Tab API",
                  "heading": "noticeicontab-api"
                },
                {
                  "depth": 3,
                  "value": "NoticeIconData",
                  "heading": "noticeicondata"
                },
                {
                  "depth": 2,
                  "value": "RightContent",
                  "heading": "rightcontent"
                }
              ],
              "hasPreviewer": true,
              "group": {
                "path": "/~docs/components",
                "title": "Components"
              }
            },
            "title": "业务组件 - ant-design-pro"
          }
        ],
        "title": "ant-design-pro",
        "component": (props) => props.children
      },
      {
        "path": "/index.html",
        "redirect": "/library/directory",
        "exact": true
      },
      {
        "path": "/",
        "redirect": "/library/directory",
        "exact": true
      },
      {
        "path": "/user",
        "layout": false,
        "routes": [
          {
            "path": "/user/login",
            "layout": false,
            "name": "login",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__user__Login' */'D:/work project/mattex/mattex-frontend-v3-jsx/src/pages/user/Login'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/user",
            "redirect": "/user/login",
            "exact": true
          },
          {
            "name": "register-result",
            "icon": "smile",
            "path": "/user/register-result",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__user__register-result' */'D:/work project/mattex/mattex-frontend-v3-jsx/src/pages/user/register-result'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "name": "register",
            "icon": "smile",
            "path": "/user/register",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__user__register' */'D:/work project/mattex/mattex-frontend-v3-jsx/src/pages/user/register'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__404' */'D:/work project/mattex/mattex-frontend-v3-jsx/src/pages/404'), loading: LoadingComponent}),
            "exact": true
          }
        ]
      },
      {
        "path": "/Projects",
        "icon": "FolderOutlined",
        "name": "projectPage",
        "routes": [
          {
            "path": "/Projects",
            "redirect": "/",
            "exact": true
          }
        ]
      },
      {
        "path": "/library",
        "icon": "ReadOutlined",
        "name": "Library",
        "routes": [
          {
            "path": "/library",
            "redirect": "/library/editor",
            "exact": true
          },
          {
            "name": "directory",
            "icon": "smile",
            "path": "/library/directory",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__library__directory' */'D:/work project/mattex/mattex-frontend-v3-jsx/src/pages/library/directory'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "hideInMenu": true,
            "name": "editor",
            "icon": "smile",
            "path": "/library/editor",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__library__editor' */'D:/work project/mattex/mattex-frontend-v3-jsx/src/pages/library/editor'), loading: LoadingComponent}),
            "exact": true
          }
        ]
      },
      {
        "path": "/CompanyProfile",
        "icon": "HddOutlined",
        "name": "Company Profile",
        "routes": [
          {
            "path": "/companys",
            "redirect": "/",
            "exact": true
          }
        ]
      },
      {
        "path": "/Settings",
        "icon": "SettingOutlined",
        "name": "Settings",
        "routes": [
          {
            "path": "/Settings",
            "redirect": "/",
            "exact": true
          }
        ]
      },
      {
        "path": "/Administration",
        "icon": "UserOutlined",
        "name": "Administration",
        "routes": [
          {
            "path": "/Administration",
            "redirect": "/",
            "exact": true
          }
        ]
      },
      {
        "hideInMenu": true,
        "hideChildrenInMenu": true,
        "path": "/form",
        "icon": "form",
        "name": "form",
        "routes": [
          {
            "path": "/form",
            "redirect": "/form/basic-form",
            "exact": true
          },
          {
            "name": "basic-form",
            "icon": "smile",
            "path": "/form/basic-form",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__form__basic-form' */'D:/work project/mattex/mattex-frontend-v3-jsx/src/pages/form/basic-form'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "name": "step-form",
            "icon": "smile",
            "path": "/form/step-form",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__form__step-form' */'D:/work project/mattex/mattex-frontend-v3-jsx/src/pages/form/step-form'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "name": "advanced-form",
            "icon": "smile",
            "path": "/form/advanced-form",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__form__advanced-form' */'D:/work project/mattex/mattex-frontend-v3-jsx/src/pages/form/advanced-form'), loading: LoadingComponent}),
            "exact": true
          }
        ]
      },
      {
        "hideInMenu": true,
        "hideChildrenInMenu": true,
        "path": "/list",
        "icon": "table",
        "name": "list",
        "routes": [
          {
            "path": "/list/search",
            "name": "search-list",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__list__search' */'D:/work project/mattex/mattex-frontend-v3-jsx/src/pages/list/search'), loading: LoadingComponent}),
            "routes": [
              {
                "path": "/list/search",
                "redirect": "/list/search/articles",
                "exact": true
              },
              {
                "name": "articles",
                "icon": "smile",
                "path": "/list/search/articles",
                "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__list__search__articles' */'D:/work project/mattex/mattex-frontend-v3-jsx/src/pages/list/search/articles'), loading: LoadingComponent}),
                "exact": true
              },
              {
                "name": "projects",
                "icon": "smile",
                "path": "/list/search/projects",
                "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__list__search__projects' */'D:/work project/mattex/mattex-frontend-v3-jsx/src/pages/list/search/projects'), loading: LoadingComponent}),
                "exact": true
              },
              {
                "name": "applications",
                "icon": "smile",
                "path": "/list/search/applications",
                "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__list__search__applications' */'D:/work project/mattex/mattex-frontend-v3-jsx/src/pages/list/search/applications'), loading: LoadingComponent}),
                "exact": true
              }
            ]
          },
          {
            "path": "/list",
            "redirect": "/list/table-list",
            "exact": true
          },
          {
            "name": "table-list",
            "icon": "smile",
            "path": "/list/table-list",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__list__table-list' */'D:/work project/mattex/mattex-frontend-v3-jsx/src/pages/list/table-list'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "name": "basic-list",
            "icon": "smile",
            "path": "/list/basic-list",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__list__basic-list' */'D:/work project/mattex/mattex-frontend-v3-jsx/src/pages/list/basic-list'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "name": "card-list",
            "icon": "smile",
            "path": "/list/card-list",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__list__card-list' */'D:/work project/mattex/mattex-frontend-v3-jsx/src/pages/list/card-list'), loading: LoadingComponent}),
            "exact": true
          }
        ]
      },
      {
        "hideInMenu": true,
        "hideChildrenInMenu": true,
        "path": "/profile",
        "name": "profile",
        "icon": "profile",
        "routes": [
          {
            "path": "/profile",
            "redirect": "/profile/basic",
            "exact": true
          },
          {
            "name": "basic",
            "icon": "smile",
            "path": "/profile/basic",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__profile__basic' */'D:/work project/mattex/mattex-frontend-v3-jsx/src/pages/profile/basic'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "name": "advanced",
            "icon": "smile",
            "path": "/profile/advanced",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__profile__advanced' */'D:/work project/mattex/mattex-frontend-v3-jsx/src/pages/profile/advanced'), loading: LoadingComponent}),
            "exact": true
          }
        ]
      },
      {
        "hideInMenu": true,
        "hideChildrenInMenu": true,
        "name": "result",
        "icon": "CheckCircleOutlined",
        "path": "/result",
        "routes": [
          {
            "path": "/result",
            "redirect": "/result/success",
            "exact": true
          },
          {
            "name": "success",
            "icon": "smile",
            "path": "/result/success",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__result__success' */'D:/work project/mattex/mattex-frontend-v3-jsx/src/pages/result/success'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "name": "fail",
            "icon": "smile",
            "path": "/result/fail",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__result__fail' */'D:/work project/mattex/mattex-frontend-v3-jsx/src/pages/result/fail'), loading: LoadingComponent}),
            "exact": true
          }
        ]
      },
      {
        "hideInMenu": true,
        "hideChildrenInMenu": true,
        "name": "exception",
        "icon": "warning",
        "path": "/exception",
        "routes": [
          {
            "path": "/exception",
            "redirect": "/exception/403",
            "exact": true
          },
          {
            "name": "403",
            "icon": "smile",
            "path": "/exception/403",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__exception__403' */'D:/work project/mattex/mattex-frontend-v3-jsx/src/pages/exception/403'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "name": "404",
            "icon": "smile",
            "path": "/exception/404",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__exception__404' */'D:/work project/mattex/mattex-frontend-v3-jsx/src/pages/exception/404'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "name": "500",
            "icon": "smile",
            "path": "/exception/500",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__exception__500' */'D:/work project/mattex/mattex-frontend-v3-jsx/src/pages/exception/500'), loading: LoadingComponent}),
            "exact": true
          }
        ]
      },
      {
        "hideInMenu": true,
        "hideChildrenInMenu": true,
        "name": "account",
        "icon": "user",
        "path": "/account",
        "routes": [
          {
            "path": "/account",
            "redirect": "/account/center",
            "exact": true
          },
          {
            "name": "center",
            "icon": "smile",
            "path": "/account/center",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__account__center' */'D:/work project/mattex/mattex-frontend-v3-jsx/src/pages/account/center'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "name": "settings",
            "icon": "smile",
            "path": "/account/settings",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__account__settings' */'D:/work project/mattex/mattex-frontend-v3-jsx/src/pages/account/settings'), loading: LoadingComponent}),
            "exact": true
          }
        ]
      },
      {
        "hideInMenu": true,
        "hideChildrenInMenu": true,
        "name": "editor",
        "icon": "highlight",
        "path": "/editor",
        "routes": [
          {
            "path": "/editor",
            "redirect": "/editor/flow",
            "exact": true
          },
          {
            "name": "flow",
            "icon": "smile",
            "path": "/editor/flow",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__editor__flow' */'D:/work project/mattex/mattex-frontend-v3-jsx/src/pages/editor/flow'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "name": "mind",
            "icon": "smile",
            "path": "/editor/mind",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__editor__mind' */'D:/work project/mattex/mattex-frontend-v3-jsx/src/pages/editor/mind'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "name": "koni",
            "icon": "smile",
            "path": "/editor/koni",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__editor__koni' */'D:/work project/mattex/mattex-frontend-v3-jsx/src/pages/editor/koni'), loading: LoadingComponent}),
            "exact": true
          }
        ]
      },
      {
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__404' */'D:/work project/mattex/mattex-frontend-v3-jsx/src/pages/404'), loading: LoadingComponent}),
        "exact": true
      }
    ]
  }
];

  // allow user to extend routes
  plugin.applyPlugins({
    key: 'patchRoutes',
    type: ApplyPluginsType.event,
    args: { routes },
  });

  return routes;
}
