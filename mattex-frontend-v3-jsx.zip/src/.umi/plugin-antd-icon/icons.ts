// @ts-nocheck

import SmileOutlined from '@ant-design/icons/SmileOutlined';
import FolderOutlined from '@ant-design/icons/FolderOutlined';
import ReadOutlined from '@ant-design/icons/ReadOutlined';
import HddOutlined from '@ant-design/icons/HddOutlined';
import SettingOutlined from '@ant-design/icons/SettingOutlined';
import UserOutlined from '@ant-design/icons/UserOutlined';
import FormOutlined from '@ant-design/icons/FormOutlined';
import TableOutlined from '@ant-design/icons/TableOutlined';
import ProfileOutlined from '@ant-design/icons/ProfileOutlined';
import CheckCircleOutlined from '@ant-design/icons/CheckCircleOutlined';
import WarningOutlined from '@ant-design/icons/WarningOutlined';
import HighlightOutlined from '@ant-design/icons/HighlightOutlined'

export default {
  SmileOutlined,
FolderOutlined,
ReadOutlined,
HddOutlined,
SettingOutlined,
UserOutlined,
FormOutlined,
TableOutlined,
ProfileOutlined,
CheckCircleOutlined,
WarningOutlined,
HighlightOutlined
}
    