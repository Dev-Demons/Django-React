const initialData = {
  layout: [],
  components: {},
};

export default initialData;
