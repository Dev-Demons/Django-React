from django.apps import AppConfig


class SmmappConfig(AppConfig):
    name = 'SMMapp'
